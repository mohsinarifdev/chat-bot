from .views import home,room
from django.urls import path

urlpatterns = [
    path("",home,name="home"),
    path("<str:room_name>/<str:user_name>",room,name="room"),
    
]
