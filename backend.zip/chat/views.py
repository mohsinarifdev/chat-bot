from django.shortcuts import render,redirect
from .models import Room, Message
# Create your views here.

def home(request):
    if request.method=="POST":
        un=request.POST["username"]
        rm=request.POST["room"]
        try:
            exi_rom=Room.objects.get(room_name=rm)
        except Room.DoesNotExist:
            nr=Room.objects.create(room_name=rm)    
        return redirect("room",rm,un)
    return render(request,"home.html")


def room(request,room_name,user_name):
    exi_rom=Room.objects.get(room_name=room_name)
    msgs=Message.objects.filter(room=exi_rom)
    content={
        "messages": msgs, 
        "user":user_name,
        "room_name": exi_rom.room_name
    }
    return render(request,"room.html",content)
